﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace _2D_RPG.Graphics.Person_Graphics
{
    class Person_Graphic
    {
        private Person_Graphic_Item Leg_Right;
        private Person_Graphic_Item Leg_Left;
        private Person_Graphic_Item Arm_Right;
        private Person_Graphic_Item Arm_Left;
        private Person_Graphic_Item Torse;
        private Person_Graphic_Item Head;

        public Person_Graphic(Point Location)
        {
            //Initialize Body Here
            //Load Position && Change Location of Body parts accordingly 
        }
    }
}
