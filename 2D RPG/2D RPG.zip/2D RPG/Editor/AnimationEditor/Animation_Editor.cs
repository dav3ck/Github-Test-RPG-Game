﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;


namespace _2D_RPG.Editor.AnimationEditor
{
    class Animation_Editor
    {

        public Animation_Editor()
        {
        }

        public void Initialize()
        {

        }

        public void Update()
        {

        }

        public void Draw()
        {

        }
    }
}
